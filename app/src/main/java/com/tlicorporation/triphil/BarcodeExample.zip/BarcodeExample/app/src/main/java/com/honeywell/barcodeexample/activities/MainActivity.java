package com.andrick.denso_ten.activities;

import android.content.Context;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.widget.NestedScrollView;

import com.andrick.denso_ten.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.honeywell.aidc.*;

public class MainActivity extends AppCompatActivity implements BarcodeReader.BarcodeListener, BarcodeReader.TriggerListener {

    private static com.honeywell.aidc.BarcodeReader barcodeReader;

    private AidcManager manager;


    private TextInputLayout textInputLayoutKanban;
    private TextInputLayout textInputLayoutLocation;
    private TextInputLayout textInputLayoutActual;

    private static TextInputEditText textInputEditTextKanban;
    private static TextInputEditText textInputEditTextLocation;
    private static TextInputEditText textInputEditTextActual;

    private static AppCompatTextView textViewStatus;

    private static String strUser;

// get bar code instance from MainActivity


    private static void startScan(){

        textInputEditTextKanban.setEnabled(true);
        textInputEditTextLocation.setEnabled(true);
        textInputEditTextActual.setEnabled(true);

        textInputEditTextKanban.setText("");
        textInputEditTextLocation.setText("");
        textInputEditTextActual.setText("");

        //textInputEditTextKanban.setInputType(InputType.TYPE_NULL);
        textInputEditTextKanban.requestFocus();


    }
    public void errorTone(){
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void WriteTextfile(String strKanban, String strLocation, String strActual) {

        String statusResult;
        if (!strActual.substring(0,5).equals(strKanban.substring(0,5))){
            statusResult = "MISMATCH";
            errorTone();
        }else if (!strActual.substring(0,5).equals(strLocation.substring(0,5))){
            statusResult = "MISMATCH" ;
            errorTone();}
        else{
            statusResult = "OK";
        }

        textViewStatus.setText(statusResult);

        String dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        String writeData = strKanban + ", " + strLocation + ", " + strActual + ", " + statusResult + ", " + dateStr + "," + strUser + "\r\n";

        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        File myFile = new File(dir ,  "scandata.csv");

        if(myFile.exists())
        {
            try
            {
                FileWriter textFileWriter = new FileWriter(myFile, true);
                BufferedWriter out = new BufferedWriter(textFileWriter);
                out.write(writeData);
                out.close();
                Log.d("file create", "File Exists: " + writeData + "/" + myFile.getName());
                textViewStatus.setText(statusResult);
            } catch(Exception e) {
                textViewStatus.setText("FILE UPDATE ERROR!");
                Log.e("file create", "error:" + e.getMessage());
            }
        }
        else
        {
            try {

                BufferedWriter out = new BufferedWriter(new FileWriter(myFile, true));
                String headerData = "Kanban, Location, Actual, Result, TimeStamp, Username" + "\r\n";
                writeData = headerData + writeData;
                out.write(writeData);
                out.close();
                Log.d("file create", myFile.getName());
            } catch (IOException e) {
                textViewStatus.setText("FILE CREATE ERROR!");
                Log.e("file create", e.getMessage());

            }
        }
    }

    private void initViews() {

        NestedScrollView nestedScrollView = findViewById(R.id.nestedScrollView);

        textInputLayoutKanban = findViewById(R.id.textInputLayoutKanban);
        textInputLayoutLocation = findViewById(R.id.textInputLayoutLocation);
        textInputLayoutActual = findViewById(R.id.textInputLayoutActual);

        textInputEditTextKanban = findViewById(R.id.textInputEditKanban);
        textInputEditTextLocation = findViewById(R.id.textInputEditTextLocation);
        textInputEditTextActual = findViewById(R.id.textInputEditTextActual);

        textViewStatus = findViewById(R.id.textViewStatus);

        strUser = getIntent().getStringExtra("NAME");


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        startScan();
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(textInputEditTextKanban.getWindowToken(), 0);


        // create the AidcManager providing a Context and a
        // CreatedCallback implementation.
        AidcManager.create(this, new AidcManager.CreatedCallback() {

            @Override
            public void onCreated(AidcManager aidcManager) {
                manager = aidcManager;
                try{
                    barcodeReader = manager.createBarcodeReader();
                }
                catch (InvalidScannerNameException e){
                    Toast.makeText(MainActivity.this, "Invalid Scanner Name Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this, "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        barcodeReader = LoginActivity.getBarcodeObject();
        textViewStatus.setText("get barcode object");
        if (barcodeReader != null) {

            // register bar code event listener
            barcodeReader.addBarcodeListener(this);

            // set the trigger mode to client control
            try {
                barcodeReader.setProperty(BarcodeReader.PROPERTY_TRIGGER_CONTROL_MODE,
                        BarcodeReader.TRIGGER_CONTROL_MODE_AUTO_CONTROL);
            } catch (UnsupportedPropertyException e) {
                Toast.makeText(this, "Failed to apply properties", Toast.LENGTH_SHORT).show();
            }
            // register trigger state change listener
            barcodeReader.addTriggerListener(this);

            Map<String, Object> properties = new HashMap<String, Object>();
            // Set Symbologies On/Off
            properties.put(BarcodeReader.PROPERTY_CODE_128_ENABLED, true);
            properties.put(BarcodeReader.PROPERTY_GS1_128_ENABLED, true);
            properties.put(BarcodeReader.PROPERTY_QR_CODE_ENABLED, true);
            properties.put(BarcodeReader.PROPERTY_CODE_39_ENABLED, true);
            properties.put(BarcodeReader.PROPERTY_DATAMATRIX_ENABLED, true);
            properties.put(BarcodeReader.PROPERTY_UPC_A_ENABLE, true);
            properties.put(BarcodeReader.PROPERTY_EAN_13_ENABLED, false);
            properties.put(BarcodeReader.PROPERTY_AZTEC_ENABLED, false);
            properties.put(BarcodeReader.PROPERTY_CODABAR_ENABLED, false);
            properties.put(BarcodeReader.PROPERTY_INTERLEAVED_25_ENABLED, false);
            properties.put(BarcodeReader.PROPERTY_PDF_417_ENABLED, false);
            // Set Max Code 39 barcode length
            properties.put(BarcodeReader.PROPERTY_CODE_39_MAXIMUM_LENGTH, 10);
            // Turn on center decoding
            properties.put(BarcodeReader.PROPERTY_CENTER_DECODE, true);
            // Enable bad read response
            properties.put(BarcodeReader.PROPERTY_NOTIFICATION_BAD_READ_ENABLED, true);
            // Sets time period for decoder timeout in any mode
            properties.put(BarcodeReader.PROPERTY_DECODER_TIMEOUT,  400);
            // Apply the settings
            barcodeReader.setProperties(properties);

            textViewStatus.setText("barcode set");
        }
        else{
            textViewStatus.setText("barcode null");
        }

        /*
        textInputEditTextKanban.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    //Toast.makeText(getApplicationContext(),KeyEvent.keyCodeToString(keyCode),Toast.LENGTH_SHORT).show();
                    switch (keyCode)
                    {

                        case KeyEvent.KEYCODE_ENTER:
                        case KeyEvent.KEYCODE_TAB:

                            if (textInputEditTextKanban.getText().length() < 13) {
                                textViewStatus.setText("INVALID KANBAN!");
                                textInputEditTextKanban.setError("INVALID KANBAN!");
                                //hideKeyboard(this);
                                //hideKeyboardFrom(textInputEditTextKanban);
                                errorTone();
                                startScan();
                            }
                            else{
                                textViewStatus.setText("OK KANBAN!");
                                textInputEditTextLocation.setEnabled(true);
                                textInputEditTextLocation.setFocusable(true);
                                textInputEditTextLocation.setFocusableInTouchMode(true);
                                textInputEditTextLocation.requestFocus();

                            }
                            return true;
                        default:
                            break;
                    }
                }
                return false;
            }
        });

         */

        /*
        textInputEditTextLocation.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    //Toast.makeText(getApplicationContext(),KeyEvent.keyCodeToString(keyCode),Toast.LENGTH_SHORT).show();
                    switch (keyCode)
                    {
                        case KeyEvent.KEYCODE_ENTER:
                        case KeyEvent.KEYCODE_TAB:
                            if (textInputEditTextLocation.getText().length() != 5){
                                textViewStatus.setText("INVALID LOCATION!");
                                textInputEditTextLocation.setError("INVALID LOCATION!");
                                errorTone();
                                startScan();
                            }else if (!textInputEditTextLocation.getText().toString().substring(0,5).equals(textInputEditTextKanban.getText().toString().substring(0,5))) {
                                textViewStatus.setText("MISMATCH!");
                                textInputEditTextLocation.setError("MISMATCH!");
                                errorTone();
                                startScan();
                            }
                            else{
                                textViewStatus.setText("OK LOCATION");
                                 textInputEditTextActual.setEnabled(true);
                                textInputEditTextActual.requestFocus();
                            }
                            return true;
                        default:
                            break;
                    }
                }
                return false;
            }
        });

        textInputEditTextActual.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (textInputEditTextActual.getText().length() >= 13){
                        WriteTextfile(textInputEditTextKanban.getText().toString(), textInputEditTextLocation.getText().toString(), textInputEditTextActual.getText().toString());
                    }
                    else{
                        errorTone();
                        textViewStatus.setText("INVALID ACTUAL!");
                    }
                    startScan();
                }
            }
        });

 */
    }






    @Override
    public void onBarcodeEvent(final BarcodeReadEvent event) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // update UI to reflect the data
                List<String> list = new ArrayList<String>();
                list.add("Barcode data: " + event.getBarcodeData());
                list.add("Character Set: " + event.getCharset());
                list.add("Code ID: " + event.getCodeId());
                list.add("AIM ID: " + event.getAimId());
                list.add("Timestamp: " + event.getTimestamp());
                textViewStatus.setText(event.getBarcodeData().toString());
                //Toast.makeText(getApplicationContext(),event.getBarcodeData().toString(),Toast.LENGTH_SHORT).show();

                //final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(
                //        AutomaticBarcodeActivity.this, android.R.layout.simple_list_item_1, list);

                //barcodeList.setAdapter(dataAdapter);
            }
        });
    }

    @Override
    public void onFailureEvent(BarcodeFailureEvent barcodeFailureEvent) {

    }

    @Override
    public void onResume() {
        super.onResume();
        if (barcodeReader != null) {
            try {
                barcodeReader.claim();
            } catch (ScannerUnavailableException e) {
                e.printStackTrace();
                Toast.makeText(this, "Scanner unavailable", Toast.LENGTH_SHORT).show();
            }
        }
    }
    @Override
    public void onPause() {
        super.onPause();
        if (barcodeReader != null) {
            // release the scanner claim so we don't get any scanner
            // notifications while paused.
            barcodeReader.release();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (barcodeReader != null) {
            // unregister barcode event listener
            barcodeReader.removeBarcodeListener(this);

            // unregister trigger state change listener
            barcodeReader.removeTriggerListener(this);
        }

        if (barcodeReader != null) {
            // close BarcodeReader to clean up resources.
            barcodeReader.close();
            barcodeReader = null;
        }

        if (manager != null) {
            // close AidcManager to disconnect from the scanner service.
            // once closed, the object can no longer be used.
            manager.close();
        }

    }

    @Override
    public void onTriggerEvent(TriggerStateChangeEvent triggerStateChangeEvent) {

    }
}