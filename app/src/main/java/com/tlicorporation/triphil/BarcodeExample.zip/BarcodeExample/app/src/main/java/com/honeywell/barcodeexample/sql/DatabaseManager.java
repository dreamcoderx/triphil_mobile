package com.andrick.denso_ten.sql;

/**
 * Created by IceMann on 23/2/2017.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseManager {
    private DatabaseHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public DatabaseManager(Context c) {
        this.context = c;
    }

    public DatabaseManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(String userid, String username, String useremail, String userpassword) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(dbHelper.COLUMN_USER_ID, userid);
        contentValues.put(dbHelper.COLUMN_USER_NAME, username);
        contentValues.put(dbHelper.COLUMN_USER_EMAIL, useremail);
        contentValues.put(dbHelper.COLUMN_USER_PASSWORD, userpassword);
        database.insert(dbHelper.TABLE_USER, null, contentValues);
    }

    public void update(String userid, String username, String useremail, String userpassword) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(dbHelper.COLUMN_USER_ID, userid);
        contentValues.put(dbHelper.COLUMN_USER_NAME, username);
        contentValues.put(dbHelper.COLUMN_USER_EMAIL, useremail);
        contentValues.put(dbHelper.COLUMN_USER_PASSWORD, userpassword);
        database.update(dbHelper.TABLE_USER, contentValues, dbHelper.COLUMN_USER_ID + " = " + userid, null);
    }

    public void delete(int id) {
        database.delete(dbHelper.TABLE_USER,dbHelper.COLUMN_USER_ID + " ='" + id + "'",null);
    }

    public Cursor fetch() {
        String[] columns = new String[]{dbHelper.COLUMN_USER_ID, dbHelper.COLUMN_USER_NAME, dbHelper.COLUMN_USER_EMAIL};
        Cursor cursor = database.query(dbHelper.TABLE_USER, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
}
